<?php
include 'config.php';

if(isset($_SESSION['user_id'])) {
    $uid = $_SESSION['user_id'];
    $msg = $conn->real_escape_string($_POST['mensaje']);
    $nombre_archivo = null;

    // Verificar si se subió un archivo
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
        $extension = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        // Generar nombre único para evitar duplicados
        $nombre_archivo = time() . "_" . bin2hex(random_bytes(5)) . "." . $extension;
        $ruta_destino = "uploads/" . $nombre_archivo;
        
        move_uploaded_file($_FILES['foto']['tmp_name'], $ruta_destino);
    }

    $sql = "INSERT INTO mensajes (usuario_id, mensaje, archivo) VALUES ($uid, '$msg', '$nombre_archivo')";
    $conn->query($sql);
}
?>