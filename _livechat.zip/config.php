<?php
session_start();

$host = "localhost";
$user = "u336643015_livechat"; 
$pass = "Livechat1234@"; 
$db   = "u336643015_livechat";

// Crear conexión
$conn = new mysqli($host, $user, $pass, $db);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Configurar caracteres para que acepten acentos y ñ
$conn->set_charset("utf8mb4");
?>