<?php
include 'config.php';

if (isset($_POST['action'])) {
    $nombre = $conn->real_escape_string($_POST['nombre']);
    $pass = password_hash($_POST['password'], PASSWORD_BCRYPT);

    if ($_POST['action'] == 'register') {
        $sql = "INSERT INTO usuarios (nombre, password) VALUES ('$nombre', '$pass')";
        if ($conn->query($sql)) echo "Registro éxito";
        else echo "Error: El usuario ya existe";
    }

    if ($_POST['action'] == 'login') {
        $res = $conn->query("SELECT * FROM usuarios WHERE nombre = '$nombre'");
        $user = $res->fetch_assoc();
        if ($user && password_verify($_POST['password'], $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['nombre'];
            header("Location: index.php");
        } else {
            echo "Datos incorrectos";
        }
    }
}
?>