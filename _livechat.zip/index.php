<?php include 'config.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Chat con Login</title>
    <style>
        body { font-family: sans-serif; background: #f4f4f4; text-align: center; }
        .box { background: white; padding: 20px; border-radius: 8px; display: inline-block; margin-top: 50px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        #chat-box { width: 400px; text-align: left; }
        #mensajes { height: 300px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; margin-bottom: 10px; }
        input { width: 80%; padding: 10px; margin: 5px 0; }
        button { padding: 10px 20px; cursor: pointer; background: #007bff; color: white; border: none; }
    </style>
</head>
<body>

<?php if (!isset($_SESSION['user_id'])): ?>
    <div class="box">
        <h2>Iniciar Sesión</h2>
        <form action="auth.php" method="POST">
            <input type="text" name="nombre" placeholder="Usuario" required><br>
            <input type="password" name="password" placeholder="Contraseña" required><br>
            <button type="submit" name="action" value="login">Entrar</button>
            <button type="submit" name="action" value="register" style="background: #28a745;">Registrarse</button>
        </form>
    </div>
<?php else: ?>
<div class="box" id="chat-box">
    <h3>Bienvenido, <?php echo $_SESSION['username']; ?></h3>
    <div id="mensajes"></div>
    <div style="display:flex; flex-direction:column; gap:5px;">
        <input type="text" id="msg" placeholder="Escribe un mensaje...">
        <input type="file" id="foto" accept="image/*"> <button onclick="enviar()">Enviar</button>
    </div>
</div>
    
    <script>
async function enviar() {
    const msg = document.getElementById('msg').value;
    const foto = document.getElementById('foto').files[0];
    
    if(!msg && !foto) return;

    const data = new FormData();
    data.append('mensaje', msg);
    if(foto) {
        data.append('foto', foto);
    }

    await fetch('send_msg.php', { method: 'POST', body: data });
    
    // Limpiar campos
    document.getElementById('msg').value = '';
    document.getElementById('foto').value = '';
    cargar();
}

// Esta función solicita los mensajes al servidor
async function cargar() {
    try {
        const res = await fetch('get_msgs.php');
        const data = await res.json();
        
        const mensajesDiv = document.getElementById('mensajes');
        
        // Guardamos la posición del scroll antes de actualizar
        const estaAlFinal = mensajesDiv.scrollHeight - mensajesDiv.scrollTop <= mensajesDiv.clientHeight + 50;

        mensajesDiv.innerHTML = data.map(m => {
            let contenido = `<div class="msg-item"><strong>${m.nombre}:</strong> ${m.mensaje}`;
            if(m.archivo) {
                contenido += `<br><img src="uploads/${m.archivo}" style="max-width:200px; border-radius:5px; margin-top:5px;">`;
            }
            contenido += `</div>`;
            return contenido;
        }).join('');

        // Si el usuario estaba abajo, bajamos el scroll al nuevo mensaje
        if (estaAlFinal) {
            mensajesDiv.scrollTop = mensajesDiv.scrollHeight;
        }
    } catch (error) {
        console.error("Error cargando mensajes:", error);
    }
}

// AQUÍ ESTÁ EL TRUCO: Ejecutar cada 2000 milisegundos (2 segundos)
setInterval(cargar, 200);

// También cargamos una vez al abrir la página
document.addEventListener('DOMContentLoaded', cargar);
    </script>
<?php endif; ?>

</body>
</html>