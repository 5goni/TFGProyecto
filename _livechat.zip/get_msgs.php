<?php
include 'config.php';
$res = $conn->query("SELECT u.nombre, m.mensaje, m.archivo FROM mensajes m JOIN usuarios u ON m.usuario_id = u.id ORDER BY m.fecha DESC LIMIT 20");
echo json_encode(array_reverse($res->fetch_all(MYSQLI_ASSOC)));
?>